:- dynamic fact/2.
:- dynamic fact/1.



tri(A,B,C):-
    readfact(line([A,B])),
    readfact(line([B,C])),
    readfact(line([C,A])).

on_startup():- (List = 
    [
        lines,
        dir(_),
        constructlines2
    ],
    importData('inputData.txt'),
    findall(X,(member(X,List),call(X)),Z),not(length(Z,0))).



solve():- (List = 
    [
        pyt(_,_,_),
        con_line(_,_),
        
        len(_,_),
        len,
        per(),
        par(_,_),
        angle(_,_),
        con_tri(_,_,_,_,_,_),
        simillar(_,_,_,_,_,_),
        rightangle(_,_),
        opositeangle,
        straightangle,
        fullangle,
        angleSum
    ],
    findall(X,(member(X,List),call(X)),Z),not(length(Z,0)),
    solve()
    ).

:-initialization(
    ([congruent],[readfacts],[pythagoras],[examples],[directions],[input],[output],(dynamic fact/2),(dynamic fact/1),on_startup,ignore(time(solve)))
).