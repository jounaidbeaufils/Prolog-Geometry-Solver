:- dynamic fact/2.
:- dynamic fact/1.
readfact(line([A,B])):- fact(line([A,B]));fact(line([B,A])).

readfact(len(line([A,B]),X),H):- fact(len(line([A,B]),X),H);fact(len(line([B,A]),X),H).
readfact(ang(line([A,B]),X),H):- fact(len(line([A,B]),X),H);fact(len(line([B,A]),X),H).

readfact(colin(A,B,C),H):- 

    fact(colin(A,B,C),H);
    fact(colin(C,B,A),H).

readfact(angle(line([A,B]),line([B,C]),X),H):- 

    fact(angle(line([A,B]),line([B,C]),X),H).

readfact(dirangle(D1,D2,X),H):-

    fact(dirangle(D1,D2,X),H).

readfact(per(line([A,B]),line([C,D])),H):- 

    fact(per(line([A,B]),line([C,D])),H);
    % fact(per(line([A,B]),line([C,B])),H);
    fact(per(line([B,A]),line([D,C])),H).
    % fact(per(line([B,A]),line([C,B])),H);

    % fact(per(line([C,B]),line([B,A])),H);
    % fact(per(line([C,D]),line([A,B])),H);
    % fact(per(line([D,C]),line([B,A])),H).
    % fact(per(line([B,C]),line([A,B])),H).

readfact(par(line([A,B]),line([C,D])),H):- 

    fact(par(line([A,B]),line([C,D])),H);
    % fact(par(line([A,B]),line([C,B])),H);
    % fact(par(line([B,A]),line([B,C])),H);
    fact(par(line([B,A]),line([D,C])),H);

    fact(par(line([C,D]),line([A,B])),H);
    % fact(par(line([C,B]),line([A,B])),H);
    fact(par(line([D,C]),line([B,A])),H).
    % fact(par(line([B,C]),line([A,B])),H).

readfact(con_line(line([A,B]),line([C,D])),H):- 

    fact(con_line(line([A,B]),line([C,D])),H);
    fact(con_line(line([A,B]),line([D,C])),H);
    fact(con_line(line([B,A]),line([C,D])),H);
    fact(con_line(line([B,A]),line([D,C])),H);
    
    fact(con_line(line([C,D]),line([A,B])),H);
    fact(con_line(line([C,D]),line([B,A])),H);
    fact(con_line(line([D,C]),line([A,B])),H);
    fact(con_line(line([D,C]),line([B,A])),H).


readfact(con_tri(A,B,C,D,E,F),H):-

    fact(con_tri(A,B,C,D,E,F),H);
    % fact(con_tri(A,B,C,D,F,E),H);
    % fact(con_tri(A,B,C,E,D,F),H);
    % fact(con_tri(A,B,C,E,F,D),H);
    % fact(con_tri(A,B,C,F,D,E),H);
    % fact(con_tri(A,B,C,F,E,D),H);
    
    % fact(con_tri(A,C,B,D,E,F),H);
    fact(con_tri(A,C,B,D,F,E),H);
    % fact(con_tri(A,C,B,E,D,F),H);
    % fact(con_tri(A,C,B,E,F,D),H);
    % fact(con_tri(A,C,B,F,D,E),H);
    % fact(con_tri(A,C,B,F,E,D),H);

    % fact(con_tri(C,A,B,D,E,F),H);
    % fact(con_tri(C,A,B,D,F,E),H);
    % fact(con_tri(C,A,B,E,D,F),H);
    % fact(con_tri(C,A,B,E,F,D),H);
    fact(con_tri(C,A,B,F,D,E),H);
    % fact(con_tri(C,A,B,F,E,D),H);
    
    % fact(con_tri(C,B,A,D,E,F),H);
    % fact(con_tri(C,B,A,D,F,E),H);
    % fact(con_tri(C,B,A,E,D,F),H);
    % fact(con_tri(C,B,A,E,F,D),H);
    % fact(con_tri(C,B,A,F,D,E),H);
    fact(con_tri(C,B,A,F,E,D),H);

    % fact(con_tri(B,A,C,D,E,F),H);
    % fact(con_tri(B,A,C,D,F,E),H);
    fact(con_tri(B,A,C,E,D,F),H);
    % fact(con_tri(B,A,C,E,F,D),H);
    % fact(con_tri(B,A,C,F,D,E),H);
    % fact(con_tri(B,A,C,F,E,D),H);
    
    % fact(con_tri(B,C,A,D,E,F),H);
    % fact(con_tri(B,C,A,D,F,E),H);
    % fact(con_tri(B,C,A,E,D,F),H);
    fact(con_tri(B,C,A,E,F,D),H);
    % fact(con_tri(B,C,A,F,D,E),H);
    % fact(con_tri(B,C,A,F,E,D),H);

    fact(con_tri(D,E,F,A,B,C),H);
    % fact(con_tri(D,E,F,A,C,B),H);
    % fact(con_tri(D,E,F,B,A,C),H);
    % fact(con_tri(D,E,F,B,C,A),H);
    % fact(con_tri(D,E,F,C,A,B),H);
    % fact(con_tri(D,E,F,C,B,A),H);
    
    % fact(con_tri(D,F,E,A,B,C),H);
    fact(con_tri(D,F,E,A,C,B),H);
    % fact(con_tri(D,F,E,B,A,C),H);
    % fact(con_tri(D,F,E,B,C,A),H);
    % fact(con_tri(D,F,E,C,A,B),H);
    % fact(con_tri(D,F,E,C,B,A),H);

    % fact(con_tri(F,D,E,A,B,C),H);
    % fact(con_tri(F,D,E,A,C,B),H);
    % fact(con_tri(F,D,E,B,A,C),H);
    % fact(con_tri(F,D,E,B,C,A),H);
    fact(con_tri(F,D,E,C,A,B),H);
    % fact(con_tri(F,D,E,C,B,A),H);
    
    % fact(con_tri(F,E,D,A,B,C),H);
    % fact(con_tri(F,E,D,A,C,B),H);
    % fact(con_tri(F,E,D,B,A,C),H);
    % fact(con_tri(F,E,D,B,C,A),H);
    % fact(con_tri(F,E,D,C,A,B),H);
    fact(con_tri(F,E,D,C,B,A),H);

    % fact(con_tri(E,D,F,A,B,C),H);
    % fact(con_tri(E,D,F,A,C,B),H);
    fact(con_tri(E,D,F,B,A,C),H);
    % fact(con_tri(E,D,F,B,C,A),H);
    % fact(con_tri(E,D,F,C,A,B),H);
    % fact(con_tri(E,D,F,C,B,A),H);
    
    % fact(con_tri(E,F,D,A,B,C),H);
    % fact(con_tri(E,F,D,A,C,B),H);
    % fact(con_tri(E,F,D,B,A,C),H);
    fact(con_tri(E,F,D,B,C,A),H).
    % fact(con_tri(E,F,D,C,A,B),H);
    % fact(con_tri(E,F,D,C,B,A),H).

readfact(simillar(A,B,C,D,E,F),H):-
    fact(simillar(A,B,C,D,E,F),H);
    fact(simillar(A,C,B,D,F,E),H);
    fact(simillar(C,A,B,F,D,E),H);
    fact(simillar(C,B,A,F,E,D),H);
    fact(simillar(B,A,C,E,D,F),H);
    fact(simillar(B,C,A,E,F,D),H);
    fact(simillar(D,E,F,A,B,C),H);
    fact(simillar(D,F,E,A,C,B),H);
    fact(simillar(F,D,E,C,A,B),H);
    fact(simillar(F,E,D,C,B,A),H);
    fact(simillar(E,D,F,B,A,C),H);
    fact(simillar(E,F,D,B,C,A),H).

readfact(dir(line([A,B]),D),H):-

    fact(dir(line([A,B]),D),H);
    (fact(dir(line([B,A]),Dnew),H),D is -Dnew).



