:- dynamic fact/2.
:- dynamic fact/1.

%Example 1 ================================================================================================

% fact(line([a,b])).
% fact(line([a,d])).
% fact(line([d,c])).
% fact(line([b,c])).
% fact(line([b,d])).

%Example 1A ==============================================================================================

% % fact(per(line([b,d]),line([a,d])),["AD perp BD (given)"]).
% % fact(per(line([b,d]),line([c,d])),["CD perp BD (given)"]).
% % fact(len(line([a,b]),5),["length AB (given)"]).
% % fact(len(line([b,d]),4),["length BD (given)"]).
% % fact(con_line(line([a,d]),line([c,d])),["AD = CD (given)"]).

%Example 1B =========================================================================

% fact(len(line([a,b]),a),["given"]).
% fact(len(line([b,c]),a),["given"]).
% fact(len(line([a,d]),b),["given"]).
% fact(len(line([b,d]),b),["given"]).
% fact(len(line([c,d]),c),['given']).

%Example 2 ================================================================================

% fact(line([a,g,b])).
% fact(line([c,h,d])).
% fact(line([e,g,h,f])).
% fact(par(line([a,g]),line([c,h])),['AGB // CHD (given)']).
% fact(angle(line([e,g]),line([g,b]),60/180*pi),['angle EGB (given)']).
% fact(len(line([a,g]),10),["length AG given"]).
% fact(len(line([a,b]),25),["length AB given"]).
% fact(len(line([c,h]),10),["length CH given"]).
% fact(len(line([h,d]),15),["length HD given"]).

%Example 3 ==============================================================================
% fact(line([d,a,e])).
% fact(line([a,b])).
% fact(line([f,b,c])).
% fact(line([a,c])).
% fact(par(line([b,c]),line([d,a])),["BC//DA (given)"]).
% fact(angle(line([c,a]),line([a,d]),120),["angle CAD (given)"]).
% fact(angle(line([f,b]),line([b,a]),120),["angle ABF (given)"]).

%Example 4 =================================================================================
% fact(line([a,b])).
% fact(line([b,c])).
% fact(line([c,d])).
% fact(line([d,a])).
% fact(line([a,e,c])).
% fact(line([b,e,d])).
% fact(per(line([a,b]),line([b,c])),["AB per BC (given)"]).
% fact(par(line([a,b]),line([d,c])),["AB//DC (given)"]).
% fact(par(line([b,c]),line([a,d])),["BC//AD (given)"]).
% fact(len(line([a,b]),4),["length AB (given)"]).
% fact(len(line([b,c]),3),["length BC (given)"]).
%Example 5 =========================================================================
% fact(line([a,e,b])).
% fact(line([g,o,h])).
% fact(line([c,f,d])).
% fact(line([a,g,c])).
% fact(line([e,o,f])).
% fact(line([b,h,d])).
% fact(line([a,i,o,l,d])).
% fact(line([b,j,o,k,c])).
% fact(line([g,i,e])).
% fact(line([e,g,h])).
% fact(line([j,k,f])).
% fact(line([f,l,h])).
% fact(par(line([a,e]),line([c,f])),["given"]).
% fact(par(line([c,f]),line([g,o])),["given"]).
% fact(par(line([b,h]),line([e,o])),["given"]).
% fact(par(line([e,o]),line([a,g])),[]).
% fact(per(line([g,c]),line([c,f])),[]).
% fact(con_line(line([a,b]),line([a,c])),[]).
% fact(con_line(line([a,c]),line([c,d])),[]).
% fact(con_line(line([c,d]),line([b,d])),[]).
% fact(con_tri(a,e,g,e,b,h),[]).
% fact(con_tri(e,b,h,h,d,f),[]).
% fact(con_tri(h,d,f,g,c,g),[]).
% fact(con_tri(f,d,g,g,a,e),[]).

%Example 6 --------------------------------------------------------------------
% fact(line([a,b,e])).
% fact(line([a,c])).
% fact(line([c,b])).
% fact(line([c,e])).
% fact(line([b,d])).
% fact(line([d,e])).
% fact(simillar(a,b,c,d,e,b)).
% fact(angle(line([a,c]),line([c,e]),90), ['given']).
% fact(angle(line([a,b]),line([b,d]),125), ['given']).
% fact(angle(line([b,a]),line([a,c]),80), ['given']).
