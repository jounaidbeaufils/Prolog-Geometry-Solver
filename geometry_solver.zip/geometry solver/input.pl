
importData(File) :-
    setup_call_cleanup(open(File, read, In),
       stream_lines(In),
       close(In)).

stream_lines(In):-
    at_end_of_stream(In).

stream_lines(In) :-
    read_line_to_string(In,X),
    ((  X = "",stream_lines(In));
    (    
        not(X=""),
        split_string(X," "," ",Z),
        atomics_to_string(Z,Q),
        term_string(Y,Q),
        handle_input(Y),
        stream_lines(In)
    )).

    

handle_input(X):-
    (
        X = line(List),!,
        assert(fact(line(List)))
    );
    (
        X = angle(A,B,C,Y),!,
        upcase_atom(A,A1), upcase_atom(B,B1),upcase_atom(C,C1),
        atomics_to_string(['Angle ', A1,B1,C1,'=',Y, ' (given)'], Text),
        assert(fact(angle(line([A,B]), line([B,C]), Y), [Text]))
    );
    (
        X = congruent(A,B,C,D,E,F),!,
        upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),upcase_atom(E,E1),upcase_atom(F,F1),
        atomics_to_string(['tri ',A1,B1,C1,' == tri ',D1,E1,F1,'(given)'],Text),
        assert(fact(con_tri(A,B,C,D,E,F),[Text]))
    );
    (
        X = simillar(A,B,C,D,E,F),!,
        upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),upcase_atom(E,E1),upcase_atom(F,F1),
        atomics_to_string(['tri ',A1,B1,C1,' simillar tri ',D1,E1,F1],Text),
        assert(fact(simillar(A,B,C,D,E,F),[Text]))
    );
    (
        X = eq_line(A,B,C,D),!,
        upcase_atom(A,A1), upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),
        atomics_to_string([A1,B1, ' = ', C1,D1, ' (given)'], Text),
        assert(fact(con_line(line([A,B]), line([C,D])), [Text]))
    );
    (
        X = length(A,B,Y),!,
        upcase_atom(A,A1), upcase_atom(B,B1),
        atomics_to_string(['Length ', A1,B1, ' = ', Y, ' (given)'], Text),
        assert(fact(len(line([A,B]), Y), [Text]))
    );
    (
        X = perp(A,B,C,D),!,
        upcase_atom(A,A1), upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),
        atomics_to_string([A1,B1, ' perp to ', C1,D1, ' (given)'], Text),
        assert(fact(per(line([A,B]), line([C,D])), [Text]))
    );
    (
        X = par(A,B,C,D),!,
        upcase_atom(A,A1), upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),
        atomics_to_string([A1,B1, ' // ', C1,D1, ' (given)'], Text),
        assert(fact(par(line([A,B]), line([C,D])), [Text]))
    ).


