:- dynamic fact/2.
:- dynamic fact/1.

%EXAMPLE 1 ########################################################################
% fact(line([a,b])).
% fact(line([b,c])).
% fact(line([a,c])).

% fact(line([d,e])).
% fact(line([e,f])).
% fact(line([d,f])).

% fact(len(line([a,b]), 3),["length AB (given)"]).
% fact(len(line([b,c]), 4),["length BC (given)"]).
% fact(len(line([a,c]), 5),["length AC (given)"]).

% fact(len(line([d,e]), 3),["length DE (given)"]).
% fact(len(line([e,f]), 4),["length EF (given)"]).
% fact(len(line([d,f]), 5),["length DF (given)"]).


% EXAMPLE 2 #####################################################################
% fact(line(a,b)).
% fact(line(b,c)).
% fact(line(c,d)).
% fact(len(line(a,b),10),["length AB (pythagoras)"]).
% fact(con_line(line(a,b),line(b,c)),["AB = BC given"]).
% fact(con_line(line(c,d),line(a,b)),["CD = AB given"]).

%EXAMPLE 3 #######################################################################
% fact(line(a,b)).
% fact(line(d,b)).
% fact(line(a,c)).
% fact(line(b,c)).
% fact(line(d,c)).
% fact(con_line(line(a,b),line(d,b)),["congruent (given)"]).
% fact(con_line(line(a,c),line(d,c)),["congruent (given)"]).

% tri(A,B,C):-
% (fact(line(A,B));fact(line(B,A))),
% (fact(line(B,C));fact(line(C,B))),
% (fact(line(A,C));fact(line(C,A))).

con_tri(A,B,C,D,E,F):-
    tri(A,B,C),tri(D,E,F),
    readfact(con_line(line([A,B]),line([D,E])),H1),readfact(con_line(line([B,C]),line([E,F])),H2),readfact(con_line(line([A,C]),line([D,F])),H3),
    \+(readfact(con_tri(A,B,C,D,E,F),_)),
    not((A=D,B=E,C=F)),%self congruency false
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),upcase_atom(E,E1),upcase_atom(F,F1),
    atomics_to_string(['tri ',A1,B1,C1,' == tri ',D1,E1,F1,'(congruent)'],Text),
    assert(fact(con_tri(A,B,C,D,E,F),[Text|[H1,H2,H3]])).

con_tri(A,B,C,D,E,F):-
    readfact(simillar(A,B,C,D,E,F),H),
    readfact(con_line(line([A,B]),line([D,E])),H1),
    not(readfact(con_tri(A,B,C,D,E,F),_)),
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),upcase_atom(E,E1),upcase_atom(F,F1),
    atomics_to_string(['tri ',A1,B1,C1,' == tri ',D1,E1,F1,'(simillar and line)'],Text),
    assert(fact(con_tri(A,B,C,D,E,F),[Text|[H,H1]])).

simillar(A,B,C,D,E,F):-
    tri(A,B,C),tri(D,E,F),
    
    readfact(dir(line([A,B]),X1),_),readfact(dir(line([B,C]),Y1),_),readfact(dir(line([A,C]),Z1),_),
    readfact(dir(line([D,E]),X2),_),readfact(dir(line([E,F]),Y2),_),readfact(dir(line([D,F]),Z2),_),
    not((A=D,B=E,C=F)),%self congruency false
    not(readfact(simillar(A,B,C,D,E,F),_)),
    not((abs(X1)=:=abs(Y1),abs(X2)=:=abs(Y2),abs(X1)=:=abs(Z1),abs(X2)=:=abs(Z2),abs(Y1)=:=abs(Z1),abs(Y2)=:=abs(Z2))),
    abs(X1)=:=abs(X2),abs(Y1)=:=abs(Y2),abs(Z1)=:=abs(Z2),
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),upcase_atom(E,E1),upcase_atom(F,F1),
    atomics_to_string(['tri ',A1,B1,C1,' simillar tri ',D1,E1,F1],Text),
    assert(fact(simillar(A,B,C,D,E,F),[Text])).

con_line(line([A,B]),line([C,D])):-
    readfact(con_tri(A,B,_,C,D,_),H),
    not(readfact(con_line(line([A,B]),line([C,D])),_)),
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),
    atomics_to_string([A1,B1,' = ',C1,D1,'(congruent triangle)'],Text),
    assert(fact(con_line(line([A,B]),line([C,D])),[Text|[H]])).

con_line(line([A,B]),line([C,D])):- 
    readfact(con_line(line([A,B]),line([C,D])),H1),
    readfact(con_line(line([C,D]),line(X,Y)),H2),
    not(readfact(con_line(line([A,B]),line([X,Y])),_)),
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(X,X1),upcase_atom(Y,Y1),
    atomics_to_string([A1,B1,' = ',X1,Y1,'(congruent lines)'],Text),
    assert(fact(con_line(line([A,B]),line([X,Y])),[Text|[H1,H2]])).

con_line(line([A,B]),line([C,D])):- 
( 
    (readfact(line([A,B])),readfact(line([C,D])),line([A,B])=line([C,D]))
), not(readfact(con_line(line([A,B]),line([C,D])),_)),
    assert(fact(con_line(line([A,B]),line([C,D])),[])).

con_line(line([A,B]),line([C,D])):- 
    (readfact(len(line([A,B]),X),H1),readfact(len(line([C,D]),Y),H2),(number(X),number(Y),X=:=Y;X=Y))
    ,not(readfact(con_line(line([A,B]),line([C,D])),_)),
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),
    atomics_to_string([A1,B1,' = ',C1,D1,'(congruent)'],Text),
    assert(fact(con_line(line([A,B]),line([C,D])),[Text|[H1,H2]])).

len(line([A,B]),X):- 
    (readfact(con_line(line([A,B]),line([C,D])),H1);readfact(con_line(line([C,D]),line([A,B])),H1)), 
    \+(readfact(len(line([A,B]),X),_)), 
    readfact(len(line([C,D]),X),H2),
    upcase_atom(A,A1),upcase_atom(B,B1),
    atomics_to_string(['length ',A1,B1,'(congruent)'],Text),
    assert(fact(len(line([A,B]),X),[Text|[H2,H1]])).
