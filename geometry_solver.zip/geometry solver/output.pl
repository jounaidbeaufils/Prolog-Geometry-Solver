out_line(A,B) :- readfact(line([A,B])).
out_congruent(A,B,C,D,E,F) :- readfact(con_tri(A,B,C,D,E,F),H),writeHistory(H).
out_simillar(A,B,C,D,E,F):- readfact(simillar(A,B,C,D,E,F),H),writeHistory(H).
out_angle(A,B,C) :- readfact(angle(line([A,B]), line([B,C]), X),H),write('Angle = '),write(X),nl,writeHistory(H).
out_eq_line(A,B,C,D) :- readfact(con_line(line([A,B]),line([C,D])),H),write(H).
out_length(A,B) :- readfact(len(line([A,B]), X),H),write('Length = '),write(X),nl,writeHistory(H).
out_par(A,B,C,D) :- readfact(par(line(A,B), line(C,D)),H),writeHistory(H).
out_perp(A,B,C,D) :- readfact(per(line(A,B),line(C,D)),H),writeHistory(H).


writeHistory(H):-
findall(
    X,
    (
        member(X,H),write1(X,0)
    ),
    _
    ).

write1(X,Y):-
    string(X),
    tab(Y),write('|'),write(X),nl.

write1(X,Y):-
    member(Xnew,X),
    Ynew is Y + 5,
    write1(Xnew,Ynew).

tabsandbars(List):-
findall(
    X,
    (
        member(X,List),tab(X),write('|')
    ),
    _
    ).
    

