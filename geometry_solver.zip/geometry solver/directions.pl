dir(line([A,B])):-
    fact(line([A,B])),
    not(readfact(dir(line([A,B]),_),_)),
    value(line([A,B]),1,Y),
    assert(fact(dir(line([A,B]),Y),[])).
    
value(line([A,B]),X,Y):-
    (
        not(readfact(dir(line([A,B]),_),_)),
        not(readfact(dir(_,X),_)),
        Y is X
    );
    (
        not(readfact(dir(line([A,B]),_),_)),
        readfact(dir(_,X),_),
        Z is X+1,
        value(line([A,B]),Z,Y)
    ).


par(line([A,B]),line([C,D])):- 
    readfact(dir(line([A,B]),D1),H1),
    readfact(dir(line([C,D]),D2),H2),
    not(readfact(par(line([A,B]),line([C,D])),_)),
    (D1 =:= D2),
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,D1),
    atomics_to_string([A1,B1,' // ',C1,D1],Text),
    assert(fact(par(line([A,B]),line([C,D])),[Text|[H1,H2]])).

par(line([A,B]),line([C,D])):-
    
    (
        readfact(par(line([A,B]),line([C,D])),H1),
        readfact(dir(line([A,B]),D1),_),
        readfact(dir(line([C,D]),D2),_),
        not(D1 =:= D2),
        abs(D1)<abs(D2), 
        retract(fact(dir(line([C,D]),D2),_)),
        assert(fact(dir(line([C,D]),D1),H1))
    );
    (
        readfact(par(line([A,B]),line([C,D])),H1),
        readfact(dir(line([A,B]),D1),_),
        readfact(dir(line([[C,D]]),D2),_),
        not(D1 =:= D2),
        abs(D2)<abs(D1), 
        retract(fact(dir(line([A,B]),D1),_)),
        assert(fact(dir(line([A,B]),D2),H1))
    ).

par(line([A,B]),line([C,D])):-
    (
        readfact(dir(line([A,B]),D1),_),
        readfact(dir(line([C,D]),D2),_),
        not(readfact(par(line([A,B]),line([C,D])),_)),
        readfact(dirangle(D1,D2,X),H),
        X =:= 180,
        assert(fact(par(line([A,B]),line([C,D])),H))
    % );
    % (
    %     readfact(dir(line([A,B]),D1),_),
    %     readfact(dir(line([C,D]),D2),_),
    %     not(readfact(par(line([A,B]),line([C,D])),_)),
    %     readfact(dirangle(D1,D2,X),H),
    %     X=:= 2*180,
    %     assert(fact(par(line([A,B]),line([C,D])),H))
    ).
    
rightangle(line([A,B]),line([B,C])):- 
    readfact(dir(line([A,B]),D1),_),
    readfact(dir(line([B,C]),D2),_),
    not(readfact(per(line([A,B]),line([B,C])),_)),
    readfact(dirangle(D1,D2,X),H),
    (X =:= 180/2),
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),
    atomics_to_string([A1,B1,' perp to ',B1,C1],Text),
    assert(fact(per(line([A,B]),line([B,C])),[Text|[H]])).

per():- 
    readfact(per(line([A,B]),line([C,D])),H1),
    readfact(dir(line([A,B]),D1),_),
    readfact(dir(line([C,D]),D2),_),
    not(readfact(dirangle(D1,D2,_),_)),
    X is 180/2,
    % upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),upcase_atom(D,E1),
    % atomics_to_string([A1,B1,' perp to ',C1,E1, (' (perpendicular)')],Text),
    assert(fact(dirangle(D1,D2,X),H1)).

angle(line([A,B]),line([B,C])):-
    readfact(dir(line([A,B]),D1),H1),
    readfact(dir(line([B,C]),D2),H2),
    not(readfact(angle(line([A,B]),line([B,C]),_),_)),
    readfact(dirangle(D1,D2,X),H3),
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),
    atomics_to_string(['angle ',A1,B1,C1],Text),
    assert(fact(angle(line([A,B]),line([B,C]),X),[Text|[H3,H1,H2]])).

angle(line([A,B]),line([B,C])):-
    readfact(angle(line([A,B]),line([B,C]),X),H),
    readfact(dir(line([A,B]),D1),_),
    readfact(dir(line([B,C]),D2),_),
    not(readfact(dirangle(D1,D2,_),_)),
    assert(fact(dirangle(D1,D2,X),H)).

colin(A,B,C):-
    readfact(par(line([A,B]),line([B,C])),H1),
    not(readfact(colin(A,B,C),_)),
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),
    atomics_to_string([A1,B1,C1,' colinear'],Text),
    assert(fact(colin(A,B,C),[Text|[H1]])).

opositeangle():-
    readfact(dirangle(D1,D2,X),H),
    D1new is -D1,
    D2new is -D2,
    not(readfact(dirangle(D1new,D2new,_),_)),
    assert(fact(dirangle(D1new,D2new,X),["opposite angle"|[H]])).

straightangle():-
(
    readfact(dirangle(D1,D2,X),H),
    D2new is -D2,
    not(readfact(dirangle(D2new,D1,_),_)),
    Xnew is 180 - X,
    assert(fact(dirangle(D2new,D1,Xnew),["straight angle"|[H]]))
);
(
    readfact(dirangle(D1,D2,X),H),
    D1new is -D1,
    not(readfact(dirangle(D2,D1new,_),_)),
    Xnew is 180 - X,
    assert(fact(dirangle(D2,D1new,Xnew),["straight angle"|[H]]))
).

fullangle():-
    readfact(dirangle(D1,D2,X),H),
    not(readfact(dirangle(D2,D1,_),_)),
    Y is 2*180-X,
    assert(fact(dirangle(D2,D1,Y),["full angle"|[H]])).

triangleSum():-
    tri(A,B,C),
    not(readfact(angle(line([B,A]),line(A,C)),_),_),
    readfact(angle(line([A,B]),line([B,C]),X1),H1),
    readfact(angle(line([C,B]),line([B,A]),X2),H2),
    readfact(angle(line([B,C]),line([C,A]),Y1),H3),
    readfact(angle(line([A,C]),line([C,B]),Y2),H4),
    (
        (
            X1 =< X2, X is X1
        );
        (
            X2<X1, X is X2,H1 = H2
        )
    ),
    (
        (
            Y1 =< Y2, Y is Y1
        );
        (
            Y2<Y1, Y is Y2, H3=H4
        )
    ),
    Z is 2*180 - X - Y,
    upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),
    atomics_to_string(['angle ',B1,A1,C1, "(triangle sum)"],Text),
    assert(fact(angle(line([B,A]),line([A,C]),Z),[Text|[H1,H2]])).
    

angleSum():-
    readfact(dir(_,D1),_),
    readfact(dir(_,D2),_),
    not(readfact(dirangle(D1,D2,_),_)),
    readfact(dirangle(D1,D3,X1),H1),
    not(readfact(dirangle(D1,D2,_),_)),
    NotD3 is -D3,
    readfact(dirangle(NotD3,D2,X2),H2),
    Xtemp is X1 + X2,
    (
        (Xtemp>=2*180, X is Xtemp - 2*180);
        (Xtemp < 2*180, X is Xtemp)
    ),
    assert(fact(dirangle(D1,D2,X),["angle sum"|[H1,H2]])).

angleSubtract():-
    readfact(dir(_,D1),_),
    readfact(dir(_,D2),_),
    not(readfact(dirangle(D1,D2,_),_)),
    readfact(dirangle(D1,D3,X1),H1),
    not(readfact(dirangle(D1,D2,_),_)),
    NotD2 is -D2,
    readfact(dirangle(NotD2,D3,X2),H2),
    Xtemp is X1 - X2,
    (
        (Xtemp>=0, X is Xtemp);
        (Xtemp < 0, X is Xtemp + 2*180)
    ),
    assert(fact(dirangle(D1,D2,X),["angle subtract"|[H1,H2]])).
% summ(D1,D2,X,H):-
%     readfact(dirangle(D1,D2,X),H1),
%     H = ["Angle Sum"|[H1]].
% summ(D1,D2,X,H):-
%     readfact(dirangle(D1,D3,X1),H1),
%     NotD3 is -D3,
%     summ(NotD3,D2,X2,H2),
%     Xtemp is X1 + X2,
%     append(H2,[H1],H),
%     (Xtemp>=2*180, X is Xtemp - 2*180);
%     (Xtemp < 2*180, X is Xtemp).


lines():-
    fact(line(List)),
    length(List,X),
    X>2,    
    constructlines(List),
    retract(fact(line(List))).

constructlines(List):-
    (
        length(List,X),
        X>=3,
        [A,B,C|T]=List,
        assert(fact(line([A,B]))),
        upcase_atom(A,A1),upcase_atom(B,B1),upcase_atom(C,C1),
        atomics_to_string([A1,B1,' // ',B1,C1,' (given)'],Text),
        assert(fact(par(line([A,B]),line([B,C])),[Text])),
        NewList = [B,C|T],
        constructlines(NewList)
    );
    (
        length(List,X),
        X=:=2,
        [A,B|_]=List,
        assert(fact(line([A,B])))
    ).

constructlines2:-
    fact(line([P1,Q1])),
    readfact(par(line([P1,Q1]),line([Q1,R1])),_),
    readfact(dir(line([P1,Q1]),X),_),
    not(fact(line([P1,R1]))),
    assert(fact(line([P1,R1]))),
    upcase_atom(P1,P2),upcase_atom(Q1,Q2),upcase_atom(R1,R2),
    atomics_to_string([P2,R2,' // ',P2,Q2,' (given)'],Text),
    assert(fact(par(line([P1,R1]),line([P1,Q1])),[Text])),
    assert(fact(dir(line([P1,R1]),X),[Text])).

    
