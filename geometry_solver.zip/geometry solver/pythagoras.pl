:- dynamic fact/2.
:- dynamic fact/1.

% fact(line([a,b])).
% fact(line([b,c])).
% fact(line([a,c])).
% fact(per(line([c,b]),line([a,c])),["BC perp AC (given)"]).

% % EXAMPLE 1 ###############################################################################################
% fact(len(line([a,b]),5),["length AB (given)"]).
% fact(len(line([a,c]),4),["length AC (given)"]).




% readfact(line([A,B])):- fact(line([A,B]));fact(line([B,A])).

% readfact(len(line([A,B]),X),H):- fact(len(line([A,B]),X),H);fact(len(line([B,A]),X),H).

% readfact(per(line([A,B]),line([B,C])),H):- 
%     fact(per(line([A,B]),line([B,C])),H);
%     fact(per(line([A,B]),line([C,B])),H);
%     fact(per(line([B,A]),line([B,C])),H);
%     fact(per(line([B,A]),line([C,B])),H).

% tri(A,B,C):-
%     readfact(line([A,B])),
%     readfact(line([B,C])),
%     readfact(line([C,A])).

len():-
    readfact(par(line([A,B]),line([B,C])),_),
    not(readfact(len(line([A,C]),_),_)),
    readfact(len(line([A,B]),X1),H1),
    readfact(len(line([B,C]),X2),H2),
    not(A = C),
    X is X1 + X2,
    upcase_atom(A,A1),upcase_atom(C,C1),upcase_atom(B,B1),
    atomics_to_string(['length ',A1,C1,' = ',A1,B1, '+',B1,C1],Text),
    assert(fact(len(line([A,C]),X),[Text|[H1,H2]])).

len():-
(
    readfact(par(line([A,B]),line([B,C])),_),
    not(readfact(len(line([A,B]),_),_)),
    readfact(len(line([B,C]),X1),H1),
    readfact(len(line([A,C]),X2),H2),
    not(A = B),
    X is X2-X1,
    upcase_atom(A,A1),upcase_atom(C,C1),upcase_atom(B,B1),
    atomics_to_string(['length ',A1,B1,' = ',A1,C1, '-',B1,C1],Text),
    assert(fact(len(line([A,B]),X),[Text|[H1,H2]]))
);
(
    readfact(par(line([A,B]),line([B,C])),_),
    not(readfact(len(line([B,C]),_),_)),
    readfact(len(line([A,B]),X1),H1),
    readfact(len(line([A,C]),X2),H2),
    X is X2-X1,
    upcase_atom(A,A1),upcase_atom(C,C1),upcase_atom(B,B1),
    atomics_to_string(['length ',B1,C1,' = ',A1,C1, '-',A1,B1],Text),
    assert(fact(len(line([B,C]),X),[Text|[H1,H2]]))
).

pyt(A,B,C):-
    tri(A,B,C),
    (
        readfact(per(line([A,B]),line([B,C])),H1),
        (
            (
                readfact(len(line([A,B]),X),H2),readfact(len(line([B,C]),Y),H3),
                not(readfact(len(line([A,C]),_),_)),
                sqrt(X*X+Y*Y,Z),
                upcase_atom(A,A1),upcase_atom(C,C1),
                atomics_to_string(['length ',A1,C1,' (pythagoras)'],Text),
                assert(fact(len(line([A,C]),Z),[Text|[H1,H2,H3]]))
            );
            (
                readfact(len(line([A,B]),X),H2),readfact(len(line([A,C]),Y),H3),
                not(readfact(len(line([B,C]),_),_)),
                sqrt(Y*Y-X*X,Z),
                upcase_atom(B,B1),upcase_atom(C,C1),
                atomics_to_string(['length ',B1,C1,' (pythagoras)'],Text),
                assert(fact(len(line([B,C]),Z),[Text|[H1,H2,H3]]))
            );
            (
                readfact(len(line([A,C]),X),H2),readfact(len(line([B,C]),Y),H3),
                not(readfact(len(line([A,B]),_),_)),
                sqrt(X*X-Y*Y,Z),
                upcase_atom(A,A1),upcase_atom(B,B1),
                atomics_to_string(['length ',A1,B1,' (pythagoras)'],Text),
                assert(fact(len(line([A,B]),Z),[Text|[H1,H2,H3]]))
            )
        )
    % );
    % (
    %     fact(per(line([B,C]),line([A,C])),H1),
    %     (
    %         (
    %             fact(len(line([B,C]),X),H2),fact(len(line([A,C]),Y),H3),
    %             not(fact(len(line([A,B]),_),_)),
    %             sqrt(X*X+Y*Y,Z),
    %             upcase_atom(B,B1),upcase_atom(A,A1),
    %             atomics_to_string(['length ',A1,B1,' (pythagoras)'],Text),
    %             assert(fact(len(line([A,B]),Z),[Text|[H1,H2,H3]]))
    %         );
    %         (
    %             fact(len(line([B,C]),X),H2),fact(len(line([A,B]),Y),H3),
    %             not(fact(len(line([A,C]),_),_)),
    %             sqrt(Y*Y-X*X,Z),
    %             upcase_atom(C,C1),upcase_atom(A,A1),
    %             atomics_to_string(['length ',A1,C1,' (pythagoras)'],Text),
    %             assert(fact(len(line([A,C]),Z),[Text|[H1,H2,H3]]))
    %         );
    %         (
    %             fact(len(line([A,B]),X),H2),fact(len(line([A,C]),Y),H3),
    %             not(fact(len(line([B,C]),_),_)),
    %             sqrt(X*X-Y*Y,Z),
    %             upcase_atom(B,B1),upcase_atom(C,C1),
    %             atomics_to_string(['length ',B1,C1,' (pythagoras)'],Text),
    %             assert(fact(len(line([B,C]),Z),[Text|[H1,H2,H3]]))
    %         )
    %     )
    % );
    % (
        % fact(per(line([A,B]),line([A,C])),H1),
        % (
        %     (
        %         fact(len(line([A,B]),X),H2),fact(len(line([A,C]),Y),H3),
        %         not(fact(len(line([B,C]),_),_)),
        %         sqrt(X*X+Y*Y,Z),
        %         upcase_atom(B,B1),upcase_atom(C,C1),
        %         atomics_to_string(['length ',B1,C1,' (pythagoras)'],Text),
        %         assert(fact(len(line([B,C]),Z),[Text|[H1,H2,H3]]))
        %     );
        %     (
        %         fact(len(line([A,B]),X),H2),fact(len(line([B,C]),Y),H3),
        %         not(fact(len(line([A,C]),_),_)),
        %         sqrt(Y*Y-X*X,Z),
        %         upcase_atom(A,A1),upcase_atom(C,C1),
        %         atomics_to_string(['length ',A1,C1,' (pythagoras)'],Text),
        %         assert(fact(len(line([A,C]),Z),[Text|[H1,H2,H3]]))
        %     );
        %     (
        %         fact(len(line([B,C]),X),H2),fact(len(line([A,C]),Y),H3),
        %         not(fact(len(line([A,B]),_),_)),
        %         sqrt(X*X-Y*Y,Z),
        %         upcase_atom(A,A1),upcase_atom(B,B1),
        %         atomics_to_string(['length ',A1,B1,' (pythagoras)'],Text),
        %         assert(fact(len(line([A,B]),Z),[Text|[H1,H2,H3]]))
        %     )
        % )
    ).